﻿using AudioComponents;

using NAudio.Wave;

using NAudioTest;

class Program
{
	[STAThread]
	public static void Main(string[] args)
	{
		Base bse = new Base();

		var audioOut = bse.Add("audio-out", new AudioOutput());

		bse.Add("440hz", new Constant(440f));
		bse.Add("441hz", new Constant(441f));
		bse.Add("amplitude", new Constant(0.5f));
		bse.Add("sine-osc", new SineOscillator());
		bse.Add("sine-osc2", new SineOscillator());

		bse.Connect("440hz", "output", "sine-osc", "frequency");
		bse.Connect("441hz", "output", "sine-osc2", "frequency");
		bse.Connect("amplitude", "output", "sine-osc", "amplitude");
		bse.Connect("amplitude", "output", "sine-osc2", "amplitude");
		bse.Connect("sine-osc", "output", "audio-out", "left-in");
		bse.Connect("sine-osc2", "output", "audio-out", "right-in");

		bse.Initialise(48000, 1000);

		var audioLink = new AudioLink(bse, audioOut);	
		using var outputDevice = new WasapiOut(NAudio.CoreAudioApi.AudioClientShareMode.Exclusive, 10);

		outputDevice.Init(audioLink);
		outputDevice.Play();
		while (outputDevice.PlaybackState == PlaybackState.Playing) Thread.Sleep(1000);
	}
}
