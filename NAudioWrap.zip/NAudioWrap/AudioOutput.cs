﻿using AudioComponents;

namespace NAudioTest;

/// <summary>
/// Just collects the input values and makes them available to the sound card.
/// </summary>
internal class AudioOutput : ComponentBase
{
	// only inputs, the output are your speakers
	private readonly Input _leftInput;
	private readonly Input _rightInput;
	
	public AudioOutput()
	{
		_leftInput = AddInput("left-in");
		_rightInput = AddInput("right-in");
	}

	public override void Tick()
	{
		// nothing here!
	}

	// expose the input as properties so the 
	internal float Left => _leftInput.Value;
	internal float Right => _rightInput.Value;
}
