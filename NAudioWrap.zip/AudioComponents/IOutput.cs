﻿namespace AudioComponents;

public interface IOutput
{
	string Name { get; }
}



public interface IInput
{
	string Name { get; }
	void FeedFrom(IOutput output);
}

public interface IOutputWriter
{
	float Value { get; }
}


public interface IInputReader
{
	float Value { get; }
}	