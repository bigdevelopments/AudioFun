﻿namespace AudioComponents;

public class Constant : ComponentBase
{
	private readonly Output _output;

	public Constant(float value = 0)
	{
		_output = AddOutput("output");
		_output.Value = value;
	}

	public void Set(float value)
	{
		_output.Value = value;
	}

	public override void Tick()
	{
		// nothing to do here
	}
}
