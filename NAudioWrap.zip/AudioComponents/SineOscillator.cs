﻿namespace AudioComponents;

public class SineOscillator : ComponentBase
{
	// inputs and outputs
	private readonly Input _frequency;
	private readonly Input  _amplitude;
	private readonly Output _output;

	// state
	private float _phase;

	public SineOscillator()
	{
		_frequency = AddInput("frequency");
		_amplitude = AddInput("amplitude");
		_output = AddOutput("output");
	}

	// tick
	public override void Tick()
	{
		float phaseIncrement = (2f * MathF.PI * _frequency.Value) / SampleRate;
		_phase += phaseIncrement;
		if (_phase >= 2f * MathF.PI) _phase -= 2f * MathF.PI;
		_output.Value = _amplitude.Value * MathF.Sin(_phase);
	}
}
