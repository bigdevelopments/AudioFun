﻿namespace AudioComponents;

public class Output : IOutput, IOutputWriter
{
	private readonly string _name;
	
	internal Output(string name)
	{
		_name = name;	
	}

	public string Name => _name;

	public float Value { get; set; }
}
